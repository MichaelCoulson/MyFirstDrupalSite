<?php

/**
 * @file
 * Contains \Drupal\masquerade\Controller\SwitchController.
 */

namespace Drupal\masquerade\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\masquerade\Masquerade;
use Drupal\user\UserInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Controller for switch and back to masquerade as user.
 */
class SwitchController extends ControllerBase {

  /**
   * The masquerade service.
   *
   * @var \Drupal\masquerade\Masquerade
   */
  protected $masquerade;

  /**
   * Constructs a new SwitchController object.
   *
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user
   * @param \Drupal\masquerade\Masquerade $masquerade
   *   The masquerade service.
   */
  public function __construct(AccountInterface $current_user, Masquerade $masquerade) {
    $this->currentUser = $current_user;
    $this->masquerade = $masquerade;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_user'),
      $container->get('masquerade')
    );
  }

  /**
   * Masquerades the current user as a given user.
   *
   * Access to masquerade as the target user account has to checked by all callers
   * via masquerade_target_user_access() already.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user account object to masquerade as.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   Redirect to previous page.
   *
   * @see this::getRedirectResponse()
   */
  public function switchTo(UserInterface $user) {
    // Store current user for messages.
    $account = $this->currentUser;
    $error = masquerade_switch_user_validate($user);
    if (empty($error)) {
      if ($this->masquerade->switchTo($user)) {
        drupal_set_message($this->t('You are now masquerading as @user.', array(
          '@user' => $account->getDisplayName(),
        )));
      }
    }
    else {
      drupal_set_message($error, 'error');
    }
    return $this->getRedirectResponse();
  }

  /**
   * Allows a user who is currently masquerading to become a new user.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request object.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   Redirect response to previous page.
   *
   * @see this::getRedirectResponse()
   */
  public function switchBack(Request $request) {
    // Store current user name for messages.
    $account_name = $this->currentUser->getDisplayName();
    if ($this->masquerade->switchBack()) {
      drupal_set_message($this->t('You are no longer masquerading as @user.', array(
        '@user' => $account_name,
      )));
    }
    else {
      drupal_set_message($this->t('Error trying unmasquerading as @user.', array(
        '@user' => $account_name,
      )), 'error');
    }
    return $this->getRedirectResponse($request);
  }

  /**
   * Returns redirect response to previous page.
   *
   * @param \Symfony\Component\HttpFoundation\Request|null $request
   *   (Optional) The request object.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   */
  protected function getRedirectResponse($request = NULL) {
    if (!isset($request)) {
      $request = \Drupal::request();
    }
    if ($redirect_path = $request->server->get('HTTP_REFERER')) {
      $url = Url::fromUri($redirect_path);
    }
    else {
      // Redirect to front page if no referrer.
      $url = Url::fromRoute('<front>');
      //$url = Url::fromRoute('user.page');
    }
    // Check access for redirected url.
    if (!$url->access($this->currentUser)) {
      // Fallback to user home page.
      $url = Url::fromRoute('user.page');
    }
    $url->setAbsolute();
    return new RedirectResponse($url->toString());
  }

}
