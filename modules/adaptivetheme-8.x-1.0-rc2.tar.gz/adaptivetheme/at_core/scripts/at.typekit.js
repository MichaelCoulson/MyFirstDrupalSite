// Required to load Typekit Kits
try{Typekit.load();}catch(e){}