
Contains a modified version of Font Awesome. 
Most partials are removed as we don't use them.

We use the CDN, however we'd really prefer to use Cloudflare, but the headers (Access-Control-Allow-Origin) are a problem.
