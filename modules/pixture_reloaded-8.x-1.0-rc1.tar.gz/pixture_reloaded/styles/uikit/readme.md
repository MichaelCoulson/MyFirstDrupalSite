Getting started...

You need bundler, nodejs and grunt installed.

http://bundler.io/ for Ruby Gems
https://nodejs.org/ for node package manager (npm) for node modules https://www.npmjs.com/
http://gruntjs.com/ our task runner

Get all that installed then fire off some commands from the theme root...

bundle install
npm install
grunt


Now edit some SCSS files in the UIKit, and remember to turn off CSS aggregation in Drupal.
